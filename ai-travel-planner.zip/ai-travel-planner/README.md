# 🧳 Agentic AI Travel Planner (LangChain + Streamlit)

An AI travel agent that plans 3–7 day trips. A LangChain **tool-calling agent** decides which tools
to call (flights, hotels, places, weather, budget), reasons over the results and returns a
day-wise itinerary as both **readable Markdown** and **structured JSON**, with a "why we chose this" section.

## Problem & objectives
Planning a trip means juggling flights, hotels, attractions, weather and budget across many sites.
This project automates that with an agent that gives personalised, justified itineraries
(use cases: travel agencies, hotel platforms, airline aggregators).

## Features
| Tool | Data | What it does |
|---|---|---|
| `flight_search` | `data/flights.json` | Cheapest / fastest direct flight; one-stop fallback |
| `hotel_recommendation` | `data/hotels.json` | Filter by stars, price, amenities; rank by value / rating / price |
| `places_discovery` | `data/places.json` | Top-rated attractions by type |
| `weather_lookup` | Open-Meteo API (no key) | Live forecast (≤15 days) or historical estimate |
| `budget_estimation` | – | Flights + hotel + food & local travel |

Two planning modes: **AI Agent (LangChain)** with OpenAI, Anthropic or Google Gemini, and a
**Rule-based** mode that runs the same tools without any API key.

## Project structure
```
app.py                    Streamlit UI
travel_agent/
  config.py               paths, city coordinates, defaults
  data_loader.py          JSON loading, city normalisation
  tools.py                flight / hotel / places / budget logic (plain, testable functions)
  weather.py              Open-Meteo client with error handling
  langchain_tools.py      LangChain StructuredTool wrappers
  agent.py                LLM factory, prompt, AgentExecutor, JSON extraction
  planner.py              rule-based planner (no LLM)
  formatting.py           plan -> Markdown
data/                     flights.json, hotels.json, places.json
tests/test_tools.py       pytest unit tests
```

## Run locally
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
streamlit run app.py
```
Pick a mode in the sidebar. For AI Agent mode paste an API key in the sidebar, or copy
`.streamlit/secrets.toml.example` to `.streamlit/secrets.toml`. Run tests with `pytest`.

## Deploy: GitHub → Streamlit Community Cloud
```bash
git init && git add . && git commit -m "AI travel planner"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
1. Go to https://share.streamlit.io → **New app** → select the repo, branch `main`, main file `app.py`.
2. **Advanced settings → Secrets**: add e.g. `OPENAI_API_KEY = "sk-..."` (never commit keys).
3. Deploy.

## Dataset notes (important)
* The flights file has only 30 flights, so many city pairs have no direct flight; the app then tries a
  one-stop route (layover time not modelled) and otherwise suggests reachable destinations.
* Flight dates in the dataset are from 2025; only the route, price and times are used.
* In `places.json` the name and `type` often disagree (e.g. "Famous Fort" of type `lake`), so places are
  shown as `Name (type)` and filtered on `type`.
* Budget assumptions: 1 room per 2 travellers, ₹1,500/person/day for food and local travel (adjustable).
