"""Unit tests for the dataset-backed tools and the rule-based planner (no network/LLM needed)."""

from datetime import date
from unittest.mock import patch

from travel_agent import planner, tools


def test_direct_flight_cheapest():
    result = tools.search_flights("Hyderabad", "Delhi")
    assert result["found"] and result["recommended"]["type"] == "direct"
    assert result["recommended"]["price"] == 2907


def test_city_aliases():
    assert tools.search_flights("Bengaluru", "new delhi")["found"]


def test_one_stop_fallback_and_missing_route():
    via_hub = tools.search_flights("Chennai", "Delhi")  # Chennai -> Hyderabad -> Delhi
    assert via_hub["recommended"]["type"] == "one_stop" and via_hub["recommended"]["price"] == 5473 + 2907
    assert not tools.search_flights("Delhi", "Goa")["found"]
    assert not tools.search_flights("Delhi", "Atlantis")["found"]


def test_same_city_rejected():
    assert not tools.search_flights("Delhi", "Delhi")["found"]


def test_hotels_filters_and_sorting():
    result = tools.recommend_hotels("Goa", min_stars=4, sort_by="price")
    prices = [h["price_per_night"] for h in result["options"]]
    assert prices == sorted(prices) and all(h["stars"] >= 4 for h in result["options"])
    assert not tools.recommend_hotels("Goa", min_stars=5, max_price=100)["found"]


def test_places_by_type_sorted_by_rating():
    result = tools.discover_places("Kolkata", types=["temple"])
    ratings = [p["rating"] for p in result["places"]]
    assert ratings == sorted(ratings, reverse=True)
    assert all(p["type"] == "temple" for p in result["places"])


def test_budget_math():
    budget = tools.estimate_budget(4800, 3200, nights=2, travelers=1, daily_local_expense=1000)
    assert budget["flights"] == 4800 and budget["hotel"] == 6400
    assert budget["food_and_local_travel"] == 3000 and budget["total"] == 14200


def test_budget_rooms_for_group():
    assert tools.estimate_budget(1000, 1000, nights=1, travelers=3)["rooms"] == 2


def test_plan_trip_end_to_end_with_weather_failure():
    offline = {"success": False, "error": "offline", "days": []}
    with patch.object(planner.weather, "get_weather", return_value=offline):
        plan = planner.plan_trip("Hyderabad", "Delhi", date(2026, 12, 1), 3, travelers=2)
    assert "error" not in plan
    assert len(plan["itinerary"]) == 3
    assert plan["budget"]["total"] == sum(
        plan["budget"][k] for k in ("flights", "hotel", "food_and_local_travel"))
    assert any("offline" in w for w in plan["warnings"])


def test_plan_trip_no_route_returns_error():
    plan = planner.plan_trip("Delhi", "Goa", date(2026, 12, 1), 3)
    assert "error" in plan
