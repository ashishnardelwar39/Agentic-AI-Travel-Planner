"""Streamlit UI for the Agentic AI Travel Planning Assistant.

Run locally:  streamlit run app.py
"""

import json
import os
from datetime import date, timedelta

import pandas as pd
import streamlit as st

from travel_agent.config import CURRENCY, MAX_TRIP_DAYS, MIN_TRIP_DAYS
from travel_agent.data_loader import (
    direct_destinations, load_flights, load_hotels, load_places, place_types, supported_cities,
)
from travel_agent.formatting import to_markdown
from travel_agent.planner import plan_trip

st.set_page_config(page_title="AI Travel Planner", page_icon="🧳", layout="wide")

AGENT_MODE = "AI Agent (LangChain)"
RULE_MODE = "Rule-based (no API key)"
KEY_NAMES = {"OpenAI": "OPENAI_API_KEY", "Anthropic": "ANTHROPIC_API_KEY", "Google Gemini": "GOOGLE_API_KEY"}


def get_secret(name: str) -> str:
    """Read a key from Streamlit secrets or the environment (never fails if neither exists)."""
    try:
        if name in st.secrets:
            return str(st.secrets[name])
    except Exception:  # no secrets file configured
        pass
    return os.getenv(name, "")


# --------------------------------------------------------------------------- sidebar
with st.sidebar:
    st.header("⚙️ Settings")
    mode = st.radio("Planning mode", [AGENT_MODE, RULE_MODE],
                    help="The agent lets an LLM decide which tools to call. "
                         "Rule-based mode runs the same tools in a fixed order.")
    provider = model = api_key = None
    if mode == AGENT_MODE:
        from travel_agent.agent import PROVIDERS  # imported here so rule-based mode needs no LangChain
        provider = st.selectbox("LLM provider", list(PROVIDERS))
        model = st.text_input("Model", value=PROVIDERS[provider])
        api_key = st.text_input(f"{provider} API key", type="password",
                                value=get_secret(KEY_NAMES[provider]),
                                help="Stored only in this session. For deployment use Streamlit secrets.")
    st.divider()
    daily_expense = st.number_input(f"Food & local travel per person/day ({CURRENCY})",
                                    min_value=0, value=1500, step=100)
    round_trip = st.checkbox("Include return flight", value=True)

st.title("🧳 Agentic AI Travel Planner")
st.caption("Flights, hotels and places come from the provided datasets; weather from the free Open-Meteo API.")

# --------------------------------------------------------------------------- request form
cities = supported_cities()
col1, col2, col3, col4 = st.columns(4)
origin = col1.selectbox("From", cities, index=cities.index("Delhi"))
destination = col2.selectbox("To", [c for c in cities if c != origin],
                             index=[c for c in cities if c != origin].index("Goa")
                             if origin != "Goa" else 0)
start_date = col3.date_input("Start date", value=date.today() + timedelta(days=7), min_value=date.today())
days = col4.slider("Trip length (days)", MIN_TRIP_DAYS, MAX_TRIP_DAYS, 3)

direct = direct_destinations(origin)
st.caption(f"Direct flights from {origin} in the dataset: {', '.join(direct) if direct else 'none'}. "
           "Other destinations use a one-stop route when available.")

col5, col6, col7, col8 = st.columns(4)
travelers = col5.number_input("Travellers", 1, 10, 1)
flight_sort = col6.selectbox("Flight preference", ["cheapest", "fastest"])
hotel_sort = col7.selectbox("Hotel preference", ["value", "rating", "price"],
                            format_func=lambda x: {"value": "Best value", "rating": "Highest rated",
                                                   "price": "Cheapest"}[x])
min_stars = col8.slider("Minimum hotel stars", 1, 5, 3)

col9, col10, col11 = st.columns([2, 2, 2])
interests = col9.multiselect("Interests (place types)", place_types())
amenities = col10.multiselect("Hotel amenities", ["wifi", "pool", "breakfast", "gym", "spa", "parking"])
budget_cap = col11.number_input(f"Total budget ({CURRENCY}, 0 = no limit)", min_value=0, value=0, step=1000)
notes = st.text_area("Anything else? (optional)", placeholder="e.g. We prefer relaxed mornings and cheap eats.")

if st.button("✨ Plan my trip", type="primary", use_container_width=True):
    st.session_state.pop("result", None)
    try:
        if mode == RULE_MODE:
            with st.spinner("Planning..."):
                plan = plan_trip(origin, destination, start_date, days, travelers, interests, flight_sort,
                                 hotel_sort, min_stars, hotel_amenities=amenities,
                                 total_budget=budget_cap or None, daily_local_expense=daily_expense,
                                 round_trip=round_trip)
            st.session_state["result"] = {"plan": plan, "steps": [], "text": ""}
        else:
            if not api_key:
                st.error(f"Please enter your {provider} API key in the sidebar (or use Rule-based mode).")
                st.stop()
            from travel_agent.agent import build_agent_executor, build_llm, run_agent
            request = (
                f"Plan a {days}-day trip from {origin} to {destination} starting {start_date.isoformat()} "
                f"for {travelers} traveller(s). Flight preference: {flight_sort}. Hotel preference: "
                f"{hotel_sort}, minimum {min_stars} stars"
                + (f", required amenities: {', '.join(amenities)}" if amenities else "")
                + (f". Interests: {', '.join(interests)}" if interests else "")
                + (f". Total budget: {CURRENCY}{budget_cap}" if budget_cap else "")
                + f". {'Include' if round_trip else 'Do not include'} a return flight. "
                f"Assume {CURRENCY}{daily_expense} per person per day for food and local travel. {notes}"
            )
            with st.spinner("The agent is calling tools and building your itinerary..."):
                executor = build_agent_executor(build_llm(provider, api_key, model))
                st.session_state["result"] = run_agent(executor, request)
    except Exception as error:  # surface API/auth errors nicely instead of a stack trace
        st.error(f"Something went wrong: {error}")

# --------------------------------------------------------------------------- results
result = st.session_state.get("result")
if result:
    plan = result.get("plan")
    if plan and plan.get("error"):
        st.error(plan["error"])
        hint = plan.get("details", {}).get("direct_destinations_from_origin")
        if hint:
            st.info(f"Try one of these destinations from {origin}: {', '.join(hint)}")
    elif plan:
        budget = plan.get("budget", {})
        m1, m2, m3 = st.columns(3)
        m1.metric("Estimated total", f"{CURRENCY}{budget.get('total', 0):,}")
        m2.metric("Hotel", plan.get("hotel", {}).get("name", "n/a"))
        m3.metric("Nights", plan.get("trip_summary", {}).get("nights", "n/a"))
        if budget.get("within_budget") is False:
            st.warning("The estimate is above your budget. Try 'Cheapest' options or fewer days.")

        tab_plan, tab_json, tab_trace = st.tabs(["📋 Itinerary", "🧾 JSON", "🔍 Agent steps"])
        with tab_plan:
            st.markdown(to_markdown(plan))
        with tab_json:
            plan_json = json.dumps(plan, indent=2, ensure_ascii=False)
            st.download_button("Download JSON", plan_json, "trip_plan.json", "application/json")
            st.code(plan_json, language="json")
        with tab_trace:
            if result.get("steps"):
                for number, step in enumerate(result["steps"], 1):
                    with st.expander(f"{number}. {step['tool']}"):
                        st.json(step["input"])
                        st.code(step["output"])
            else:
                st.info("Rule-based mode runs tools in a fixed order; use AI Agent mode to see tool calls.")
    elif result.get("text"):
        st.markdown(result["text"])
        st.info("The agent's answer did not contain a parseable JSON plan, so it is shown as plain text.")

with st.expander("📂 Browse the datasets"):
    tab_f, tab_h, tab_p = st.tabs(["Flights", "Hotels", "Places"])
    tab_f.dataframe(pd.DataFrame(load_flights()), use_container_width=True, hide_index=True)
    tab_h.dataframe(pd.DataFrame(load_hotels()), use_container_width=True, hide_index=True)
    tab_p.dataframe(pd.DataFrame(load_places()), use_container_width=True, hide_index=True)
