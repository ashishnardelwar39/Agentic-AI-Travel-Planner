"""Deterministic (no-LLM) trip planner.

It chains the same tools the LangChain agent uses, so the app works offline /
without an API key and produces the same structured plan format.
"""

from datetime import date, timedelta
from typing import Any

from . import tools, weather
from .config import CURRENCY, DEFAULT_DAILY_LOCAL_EXPENSE
from .data_loader import normalize_city


def _flight_summary(journey: dict[str, Any]) -> dict[str, Any]:
    first = journey["legs"][0]
    return {
        "type": journey["type"],
        "airline": " + ".join(leg["airline"] for leg in journey["legs"]),
        "route": " → ".join([first["from"]] + [leg["to"] for leg in journey["legs"]]),
        "departure_time": first["departure_time"],
        "arrival_time": journey["legs"][-1]["arrival_time"],
        "duration": journey["duration"],
        "price": journey["price"],
        "flight_ids": [leg["flight_id"] for leg in journey["legs"]],
    }


def _assign_places(places: list[dict[str, Any]], days: int) -> list[list[str]]:
    """Spread places over days round-robin; days without a place become free days."""
    schedule: list[list[str]] = [[] for _ in range(days)]
    for index, place in enumerate(places):
        schedule[index % days].append(f"{place['label']} — rated {place['rating']}")
    for day_activities in schedule:
        if not day_activities:
            day_activities.append("Free day: relax, shop locally or revisit a favourite spot")
    return schedule


def plan_trip(origin: str, destination: str, start_date: date, days: int, travelers: int = 1,
              interests: list[str] | None = None, flight_sort: str = "cheapest",
              hotel_sort: str = "value", min_stars: int = 3, max_hotel_price: int | None = None,
              hotel_amenities: list[str] | None = None, total_budget: int | None = None,
              daily_local_expense: float = DEFAULT_DAILY_LOCAL_EXPENSE,
              round_trip: bool = True) -> dict[str, Any]:
    """Build a complete structured itinerary. Returns ``{"error": ...}`` for impossible requests."""
    origin, destination = normalize_city(origin), normalize_city(destination)
    nights = days - 1
    end_date = start_date + timedelta(days=nights)
    reasoning: list[str] = []
    warnings: list[str] = []

    # 1) Flights ---------------------------------------------------------------------------
    outbound = tools.search_flights(origin, destination, flight_sort)
    if not outbound.get("found"):
        return {"error": outbound.get("error", "No flight found."), "details": outbound}
    outbound_journey = outbound["recommended"]
    reasoning.append("Outbound flight: " + outbound["reason"])
    if outbound.get("note"):
        warnings.append(outbound["note"])

    return_journey = None
    flight_cost_per_person = outbound_journey["price"]
    if round_trip:
        back = tools.search_flights(destination, origin, flight_sort)
        if back.get("found"):
            return_journey = back["recommended"]
            flight_cost_per_person += return_journey["price"]
            reasoning.append("Return flight: " + back["reason"])
        else:
            flight_cost_per_person *= 2
            warnings.append(f"No return flight {destination} → {origin} in the dataset; "
                            "the return fare is estimated as equal to the outbound fare.")

    # 2) Hotel -----------------------------------------------------------------------------
    hotel_result = tools.recommend_hotels(destination, min_stars, max_hotel_price, hotel_amenities, hotel_sort)
    if not hotel_result.get("found"):
        warnings.append(hotel_result["error"] + " Filters were relaxed to find a hotel.")
        hotel_result = tools.recommend_hotels(destination, sort_by=hotel_sort)
    if not hotel_result.get("found"):
        return {"error": f"No hotels available in {destination}."}
    hotel = hotel_result["recommended"]
    reasoning.append("Hotel: " + hotel_result["reason"])

    # 3) Places ----------------------------------------------------------------------------
    places_result = tools.discover_places(destination, interests, limit=max(2 * days, 6))
    places = places_result.get("places", [])
    if interests and len(places) < days:  # top up with other top-rated places
        extra = tools.discover_places(destination, limit=20).get("places", [])
        known = {p["place_id"] for p in places}
        places += [p for p in extra if p["place_id"] not in known][: days - len(places)]
        warnings.append("Few places matched the chosen interests, so other top-rated places were added.")
    reasoning.append(f"Places: top-rated attractions in {destination}"
                     + (f" matching {', '.join(interests)}." if interests else "."))
    # Keep the best places only; at most 2 per day.
    places = places[: 2 * days]

    # 4) Weather ---------------------------------------------------------------------------
    weather_result = weather.get_weather(destination, start_date.isoformat(), days)
    if not weather_result.get("success"):
        warnings.append(weather_result.get("error", "Weather unavailable."))
    weather_days = weather_result.get("days", [])
    reasoning.append(f"Weather source: {weather_result.get('source', 'unavailable')}.")

    # 5) Budget ----------------------------------------------------------------------------
    budget = tools.estimate_budget(flight_cost_per_person, hotel["price_per_night"], nights,
                                   travelers, daily_local_expense)
    if total_budget:
        difference = total_budget - budget["total"]
        budget["user_budget"] = total_budget
        budget["within_budget"] = difference >= 0
        reasoning.append(
            f"Budget: estimated {CURRENCY}{budget['total']:,} is "
            + (f"{CURRENCY}{difference:,} under" if difference >= 0 else f"{CURRENCY}{-difference:,} over")
            + f" your {CURRENCY}{total_budget:,} budget.")

    # 6) Itinerary -------------------------------------------------------------------------
    activity_plan = _assign_places(places, days)
    itinerary = []
    for index in range(days):
        day_date = start_date + timedelta(days=index)
        activities = list(activity_plan[index])
        if index == 0:
            activities.insert(0, f"Arrive in {destination}, check in at {hotel['name']}")
        if index == days - 1:
            activities.append(f"Check out and fly home to {origin}")
        itinerary.append({
            "day": index + 1, "date": day_date.isoformat(), "activities": activities,
            "weather": weather_days[index] if index < len(weather_days) else None,
        })

    return {
        "trip_summary": {
            "title": f"Your {days}-Day Trip to {destination} "
                     f"({start_date:%b %d} – {end_date:%b %d})",
            "origin": origin, "destination": destination, "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(), "days": days, "nights": nights, "travelers": travelers,
        },
        "flight": {"outbound": _flight_summary(outbound_journey),
                   "return": _flight_summary(return_journey) if return_journey else None,
                   "price_per_person_total": flight_cost_per_person},
        "hotel": {"name": hotel["name"], "stars": hotel["stars"],
                  "price_per_night": hotel["price_per_night"], "amenities": hotel["amenities"]},
        "weather": weather_days,
        "itinerary": itinerary,
        "budget": budget,
        "reasoning": reasoning,
        "warnings": warnings,
    }
