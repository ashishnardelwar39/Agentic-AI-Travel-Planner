"""Weather lookup using the free Open-Meteo API (no API key required).

* Dates within the next ~15 days use the live forecast API.
* Dates further out (or in the past) fall back to the same calendar dates from a
  previous year via the archive API, clearly labelled as a "historical estimate".
* Any network failure returns a graceful "unavailable" result instead of raising.
"""

from datetime import date, timedelta
from typing import Any

import requests

from .config import CITY_COORDINATES
from .data_loader import normalize_city

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"
ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
FORECAST_HORIZON_DAYS = 15
ARCHIVE_DELAY_DAYS = 7
REQUEST_TIMEOUT_SECONDS = 10
DAILY_FIELDS = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max"
ARCHIVE_FIELDS = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum"

WEATHER_CODES = {
    0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
    45: "Fog", 48: "Fog", 51: "Light drizzle", 53: "Drizzle", 55: "Heavy drizzle",
    56: "Freezing drizzle", 57: "Freezing drizzle", 61: "Light rain", 63: "Rain",
    65: "Heavy rain", 66: "Freezing rain", 67: "Freezing rain", 71: "Light snow",
    73: "Snow", 75: "Heavy snow", 77: "Snow grains", 80: "Rain showers",
    81: "Rain showers", 82: "Violent rain showers", 85: "Snow showers",
    86: "Snow showers", 95: "Thunderstorm", 96: "Thunderstorm with hail",
    99: "Thunderstorm with hail",
}


def describe_weather_code(code: int | None) -> str:
    """Translate a WMO weather code into readable text."""
    if code is None:
        return "Unknown"
    return WEATHER_CODES.get(int(code), "Unknown")


def _request_daily(url: str, params: dict[str, Any]) -> dict[str, list]:
    response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT_SECONDS)
    response.raise_for_status()
    payload = response.json()
    if "daily" not in payload:
        raise ValueError(payload.get("reason", "Unexpected Open-Meteo response"))
    return payload["daily"]


def _rows(daily: dict[str, list], rain_key: str) -> list[dict[str, Any]]:
    rows = []
    for index, day in enumerate(daily["time"]):
        rain = daily.get(rain_key, [None] * len(daily["time"]))[index]
        rows.append({
            "date": day,
            "condition": describe_weather_code(daily["weather_code"][index]),
            "temp_max_c": daily["temperature_2m_max"][index],
            "temp_min_c": daily["temperature_2m_min"][index],
            "rain_chance_percent" if rain_key == "precipitation_probability_max"
            else "rain_mm": rain,
        })
    return rows


def get_weather(city: str, start_date: str, days: int) -> dict[str, Any]:
    """Return a day-by-day weather summary for ``city`` starting at ``start_date`` (YYYY-MM-DD)."""
    city = normalize_city(city)
    if city not in CITY_COORDINATES:
        return {"success": False, "error": f"No coordinates for '{city}'.",
                "supported_cities": sorted(CITY_COORDINATES)}
    try:
        start = date.fromisoformat(start_date)
    except ValueError:
        return {"success": False, "error": "start_date must be in YYYY-MM-DD format."}

    days = max(1, min(int(days), 16))
    end = start + timedelta(days=days - 1)
    latitude, longitude = CITY_COORDINATES[city]
    today = date.today()
    base = {"latitude": latitude, "longitude": longitude, "timezone": "auto"}

    try:
        if today <= start and end <= today + timedelta(days=FORECAST_HORIZON_DAYS):
            daily = _request_daily(FORECAST_URL, {
                **base, "daily": DAILY_FIELDS,
                "start_date": start.isoformat(), "end_date": end.isoformat()})
            return {"success": True, "city": city, "source": "Open-Meteo live forecast",
                    "days": _rows(daily, "precipitation_probability_max")}

        # Outside the forecast window -> same dates from the most recent complete past year.
        shift_years = 1
        while end - timedelta(days=365 * shift_years) > today - timedelta(days=ARCHIVE_DELAY_DAYS):
            shift_years += 1
        offset = timedelta(days=365 * shift_years)
        daily = _request_daily(ARCHIVE_URL, {
            **base, "daily": ARCHIVE_FIELDS,
            "start_date": (start - offset).isoformat(), "end_date": (end - offset).isoformat()})
        rows = _rows(daily, "precipitation_sum")
        for index, row in enumerate(rows):
            row["date"] = (start + timedelta(days=index)).isoformat()
        return {"success": True, "city": city,
                "source": "Open-Meteo historical estimate (same dates in a past year; "
                          "live forecast only covers ~15 days ahead)",
                "days": rows}
    except (requests.RequestException, ValueError, KeyError) as error:
        return {"success": False, "city": city,
                "error": "Weather service unavailable (network error); weather shown as 'Unavailable'.",
                "days": [{"date": (start + timedelta(days=i)).isoformat(), "condition": "Unavailable",
                          "temp_max_c": None, "temp_min_c": None} for i in range(days)]}
