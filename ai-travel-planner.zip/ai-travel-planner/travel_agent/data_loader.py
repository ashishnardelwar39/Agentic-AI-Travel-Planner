"""Loading of the JSON datasets (flights, hotels, places) and city helpers."""

import json
from functools import lru_cache
from typing import Any

from .config import CITY_ALIASES, CITY_COORDINATES, DATA_DIR


@lru_cache(maxsize=None)
def _load_json(filename: str) -> tuple:
    """Read a JSON list from the data folder (cached). Returns a tuple so it is immutable."""
    path = DATA_DIR / filename
    try:
        with path.open(encoding="utf-8") as file:
            return tuple(json.load(file))
    except FileNotFoundError as error:
        raise FileNotFoundError(f"Dataset not found: {path}") from error
    except json.JSONDecodeError as error:
        raise ValueError(f"Dataset is not valid JSON: {path}") from error


def load_flights() -> list[dict[str, Any]]:
    return list(_load_json("flights.json"))


def load_hotels() -> list[dict[str, Any]]:
    return list(_load_json("hotels.json"))


def load_places() -> list[dict[str, Any]]:
    return list(_load_json("places.json"))


def normalize_city(name: str) -> str:
    """Return the canonical city name (handles case and aliases such as 'Bengaluru')."""
    cleaned = (name or "").strip()
    alias = CITY_ALIASES.get(cleaned.lower())
    if alias:
        return alias
    return cleaned.title()


def supported_cities() -> list[str]:
    return sorted(CITY_COORDINATES)


def place_types() -> list[str]:
    return sorted({place["type"] for place in load_places()})


def direct_destinations(origin: str) -> list[str]:
    """Cities reachable by a direct flight in the dataset."""
    origin = normalize_city(origin)
    return sorted({f["to"] for f in load_flights() if f["from"] == origin})
