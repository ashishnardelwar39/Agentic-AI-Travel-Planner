"""LangChain tool-calling agent that plans trips by autonomously calling the travel tools."""

import json
import re
from datetime import date
from typing import Any

from langchain.agents import AgentExecutor, create_tool_calling_agent
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder

from .langchain_tools import build_tools

PROVIDERS = {
    "OpenAI": "gpt-4o-mini",
    "Anthropic": "claude-sonnet-4-5",
    "Google Gemini": "gemini-2.5-flash",
}

SYSTEM_PROMPT = """You are an expert AI Travel Planning Agent for Indian domestic trips.
Today's date is {today}. Prices are in Indian Rupees (INR).

You have five tools: flight_search, hotel_recommendation, places_discovery, weather_lookup,
budget_estimation. ALWAYS use them; never invent flights, hotels, places or prices.

Workflow:
1. Understand the request (origin, destination, start date, number of days 3-7, travelers,
   interests, budget, preferences). If something is missing, make a sensible assumption and
   mention it in "warnings".
2. Call flight_search for the outbound flight and again for the return flight (swap cities).
   If a return flight is not found, assume the return fare equals the outbound fare and say so.
3. Call hotel_recommendation, places_discovery and weather_lookup for the destination.
4. Call budget_estimation. flight_price_per_person = outbound + return price.
   nights = days - 1.
5. Build a day-wise itinerary using ONLY places returned by places_discovery
   (use the place's "label"). Use 1-2 places per day; day 1 starts with arrival/check-in and the
   last day ends with check-out/departure.
6. Explain why you chose each option ("reasoning").

Respond with a short friendly summary and then ONE fenced ```json block with exactly this shape:
{{
  "trip_summary": {{"title": str, "origin": str, "destination": str, "start_date": "YYYY-MM-DD",
                    "end_date": "YYYY-MM-DD", "days": int, "nights": int, "travelers": int}},
  "flight": {{"outbound": {{"airline": str, "route": str, "departure_time": ISO str,
                           "duration": str, "price": int}},
              "return": {{same fields}} or null}},
  "hotel": {{"name": str, "stars": int, "price_per_night": int, "amenities": [str]}},
  "weather": [{{"date": str, "condition": str, "temp_max_c": number, "temp_min_c": number}}],
  "itinerary": [{{"day": int, "date": str, "activities": [str],
                  "weather": {{"condition": str, "temp_max_c": number, "temp_min_c": number}}}}],
  "budget": {{"flights": int, "hotel": int, "food_and_local_travel": int, "total": int,
              "assumptions": str}},
  "reasoning": [str],
  "warnings": [str]
}}
"""


def build_llm(provider: str, api_key: str, model: str | None = None, temperature: float = 0.0):
    """Create a chat model for the chosen provider (imports are lazy so only one SDK is needed)."""
    model = model or PROVIDERS[provider]
    if provider == "OpenAI":
        from langchain_openai import ChatOpenAI
        return ChatOpenAI(model=model, api_key=api_key, temperature=temperature)
    if provider == "Anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(model=model, api_key=api_key, temperature=temperature)
    if provider == "Google Gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI
        return ChatGoogleGenerativeAI(model=model, google_api_key=api_key, temperature=temperature)
    raise ValueError(f"Unknown provider: {provider}")


def build_agent_executor(llm) -> AgentExecutor:
    """Wire the LLM and tools into a tool-calling AgentExecutor."""
    prompt = ChatPromptTemplate.from_messages([
        ("system", SYSTEM_PROMPT),
        ("human", "{input}"),
        MessagesPlaceholder("agent_scratchpad"),
    ]).partial(today=date.today().isoformat())
    tools = build_tools()
    agent = create_tool_calling_agent(llm, tools, prompt)
    return AgentExecutor(agent=agent, tools=tools, max_iterations=15,
                         return_intermediate_steps=True, handle_parsing_errors=True, verbose=False)


def extract_plan_json(text: str) -> dict[str, Any] | None:
    """Pull the JSON plan out of the agent's final answer, or ``None`` if it can't be parsed."""
    fenced = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, re.DOTALL)
    candidates = [fenced.group(1)] if fenced else []
    if "{" in text and "}" in text:
        candidates.append(text[text.index("{"): text.rindex("}") + 1])
    for candidate in candidates:
        try:
            return json.loads(candidate)
        except json.JSONDecodeError:
            continue
    return None


def _normalise_output(output: Any) -> str:
    """Anthropic/Gemini may return a list of content blocks instead of a string."""
    if isinstance(output, str):
        return output
    if isinstance(output, list):
        return "".join(block.get("text", "") if isinstance(block, dict) else str(block) for block in output)
    return str(output)


def run_agent(executor: AgentExecutor, request: str) -> dict[str, Any]:
    """Run the agent and return ``{"text", "plan", "steps"}``."""
    result = executor.invoke({"input": request})
    text = _normalise_output(result["output"])
    steps = [{"tool": action.tool, "input": action.tool_input, "output": str(observation)[:2000]}
             for action, observation in result.get("intermediate_steps", [])]
    return {"text": text, "plan": extract_plan_json(text), "steps": steps}
