"""Render a structured trip plan (dict) as human-readable Markdown.

Tolerant of missing keys, because plans produced by an LLM may be incomplete.
"""

from datetime import datetime
from typing import Any

from .config import CURRENCY


def _money(value: Any) -> str:
    return f"{CURRENCY}{value:,.0f}" if isinstance(value, (int, float)) else "n/a"


def _time(iso: str | None) -> str:
    try:
        return datetime.fromisoformat(iso).strftime("%H:%M")
    except (TypeError, ValueError):
        return "n/a"


def _flight_line(label: str, flight: dict[str, Any] | None) -> str:
    if not flight:
        return f"- **{label}:** not available"
    return (f"- **{label}:** {flight.get('airline', '?')} ({flight.get('route', '')}) — "
            f"{_money(flight.get('price'))}, departs {_time(flight.get('departure_time'))}, "
            f"duration {flight.get('duration', 'n/a')}")


def _weather_line(day: dict[str, Any] | None) -> str:
    if not day:
        return "n/a"
    parts = [day.get("condition", "n/a")]
    if day.get("temp_max_c") is not None:
        low = f"/{day['temp_min_c']:.0f}" if day.get("temp_min_c") is not None else ""
        parts.append(f"{day['temp_max_c']:.0f}{low}°C")
    if day.get("rain_chance_percent") is not None:
        parts.append(f"{day['rain_chance_percent']}% rain")
    return ", ".join(parts)


def to_markdown(plan: dict[str, Any]) -> str:
    """Convert a plan dictionary to Markdown."""
    summary = plan.get("trip_summary", {})
    flight = plan.get("flight", {})
    hotel = plan.get("hotel", {})
    budget = plan.get("budget", {})
    lines = [f"## {summary.get('title', 'Your Trip')}", ""]
    lines += [f"**{summary.get('origin', '?')} → {summary.get('destination', '?')}** · "
              f"{summary.get('travelers', 1)} traveller(s) · {summary.get('nights', '?')} night(s)", ""]

    lines += ["### ✈️ Flights", _flight_line("Outbound", flight.get("outbound")),
              _flight_line("Return", flight.get("return")), ""]

    if hotel:
        lines += ["### 🏨 Hotel",
                  f"- **{hotel.get('name')}** — {hotel.get('stars')}★, "
                  f"{_money(hotel.get('price_per_night'))}/night",
                  f"- Amenities: {', '.join(hotel.get('amenities', [])) or 'n/a'}", ""]

    lines += ["### 🗓️ Day-wise itinerary"]
    for day in plan.get("itinerary", []):
        lines.append(f"**Day {day.get('day')} · {day.get('date', '')}** — "
                     f"🌤️ {_weather_line(day.get('weather'))}")
        lines += [f"- {activity}" for activity in day.get("activities", [])]
        lines.append("")

    if budget:
        lines += ["### 💰 Budget estimate",
                  f"- Flights: {_money(budget.get('flights'))}",
                  f"- Hotel: {_money(budget.get('hotel'))}",
                  f"- Food & local travel: {_money(budget.get('food_and_local_travel'))}",
                  f"- **Total: {_money(budget.get('total'))}**"]
        if budget.get("assumptions"):
            lines.append(f"- _{budget['assumptions']}_")
        lines.append("")

    if plan.get("reasoning"):
        lines += ["### 🧠 Why these choices?"] + [f"- {r}" for r in plan["reasoning"]] + [""]
    if plan.get("warnings"):
        lines += ["### ⚠️ Notes"] + [f"- {w}" for w in plan["warnings"]]
    return "\n".join(lines)
