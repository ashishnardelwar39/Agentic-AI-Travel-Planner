"""Core travel tools: flight search, hotel recommendation, places discovery, budget.

These are plain Python functions returning dictionaries so they can be unit-tested
and reused by both the LangChain agent (see ``langchain_tools.py``) and the
rule-based planner (see ``planner.py``).
"""

import math
from datetime import datetime
from typing import Any

from .config import CURRENCY, DEFAULT_DAILY_LOCAL_EXPENSE
from .data_loader import (
    direct_destinations,
    load_flights,
    load_hotels,
    load_places,
    normalize_city,
    supported_cities,
)

# --------------------------------------------------------------------------- flights


def _format_duration(minutes: int) -> str:
    return f"{minutes // 60}h {minutes % 60:02d}m"


def _flight_view(flight: dict[str, Any]) -> dict[str, Any]:
    departure = datetime.fromisoformat(flight["departure_time"])
    arrival = datetime.fromisoformat(flight["arrival_time"])
    minutes = int((arrival - departure).total_seconds() // 60)
    return {
        "flight_id": flight["flight_id"],
        "airline": flight["airline"],
        "from": flight["from"],
        "to": flight["to"],
        "departure_time": flight["departure_time"],
        "arrival_time": flight["arrival_time"],
        "duration_minutes": minutes,
        "duration": _format_duration(minutes),
        "price": flight["price"],
    }


def _journey(legs: list[dict[str, Any]], journey_type: str) -> dict[str, Any]:
    minutes = sum(leg["duration_minutes"] for leg in legs)
    return {
        "type": journey_type,
        "legs": legs,
        "price": sum(leg["price"] for leg in legs),
        "duration_minutes": minutes,
        "duration": _format_duration(minutes),
    }


def search_flights(origin: str, destination: str, sort_by: str = "cheapest",
                   max_price: int | None = None) -> dict[str, Any]:
    """Find flights from ``origin`` to ``destination``.

    Direct flights are preferred. If none exist, one-stop combinations through an
    intermediate city are suggested (layover time is NOT included in duration).
    ``sort_by`` is ``"cheapest"`` or ``"fastest"``.
    """
    origin, destination = normalize_city(origin), normalize_city(destination)
    cities = supported_cities()
    for city in (origin, destination):
        if city not in cities:
            return {"found": False, "error": f"'{city}' is not supported.", "supported_cities": cities}
    if origin == destination:
        return {"found": False, "error": "Origin and destination are the same city."}
    if sort_by not in ("cheapest", "fastest"):
        sort_by = "cheapest"

    sort_key = (lambda j: (j["price"], j["duration_minutes"])) if sort_by == "cheapest" \
        else (lambda j: (j["duration_minutes"], j["price"]))

    flights = [_flight_view(f) for f in load_flights()]
    direct = [_journey([f], "direct") for f in flights if f["from"] == origin and f["to"] == destination]
    if max_price is not None:
        direct = [j for j in direct if j["price"] <= max_price]
    if direct:
        direct.sort(key=sort_key)
        best = direct[0]
        airline = best["legs"][0]["airline"]
        return {
            "found": True, "origin": origin, "destination": destination, "sort_by": sort_by,
            "options": direct[:5], "recommended": best,
            "reason": (f"{airline} is the {sort_by} of {len(direct)} direct flight(s) "
                       f"from {origin} to {destination} ({CURRENCY}{best['price']}, {best['duration']})."),
        }

    one_stop = []
    for first in (f for f in flights if f["from"] == origin):
        for second in (f for f in flights if f["from"] == first["to"] and f["to"] == destination):
            one_stop.append(_journey([first, second], "one_stop"))
    if max_price is not None:
        one_stop = [j for j in one_stop if j["price"] <= max_price]
    if one_stop:
        one_stop.sort(key=sort_key)
        best = one_stop[0]
        hub = best["legs"][0]["to"]
        return {
            "found": True, "origin": origin, "destination": destination, "sort_by": sort_by,
            "options": one_stop[:5], "recommended": best,
            "reason": (f"No direct flight in the dataset, so a one-stop route via {hub} was chosen "
                       f"({CURRENCY}{best['price']} total)."),
            "note": "Layover time is not included in the duration; confirm connection timings.",
        }

    return {"found": False, "origin": origin, "destination": destination,
            "error": f"No direct or one-stop flights found from {origin} to {destination}.",
            "direct_destinations_from_origin": direct_destinations(origin)}


# --------------------------------------------------------------------------- hotels


def recommend_hotels(city: str, min_stars: int = 0, max_price: int | None = None,
                     amenities: list[str] | None = None, sort_by: str = "value",
                     limit: int = 5) -> dict[str, Any]:
    """Recommend hotels in ``city``.

    ``sort_by``: ``"value"`` (stars per rupee), ``"rating"`` (highest stars first) or
    ``"price"`` (cheapest first).
    """
    city = normalize_city(city)
    required = {a.strip().lower() for a in (amenities or []) if a.strip()}
    hotels = []
    for hotel in load_hotels():
        if hotel["city"] != city or hotel["stars"] < min_stars:
            continue
        if max_price is not None and hotel["price_per_night"] > max_price:
            continue
        if not required.issubset(set(hotel["amenities"])):
            continue
        hotels.append({**hotel, "value_score": round(hotel["stars"] / hotel["price_per_night"] * 1000, 2)})

    if not hotels:
        return {"found": False, "city": city,
                "error": f"No hotels in {city} match these filters. Try lowering min_stars, "
                         "raising max_price or removing amenities."}

    sorters = {
        "value": (lambda h: (-h["value_score"], h["price_per_night"]),
                  "best value (most stars per rupee)"),
        "rating": (lambda h: (-h["stars"], h["price_per_night"]),
                   "highest star rating (cheapest among ties)"),
        "price": (lambda h: (h["price_per_night"], -h["stars"]), "lowest nightly price"),
    }
    if sort_by not in sorters:
        sort_by = "value"
    key, label = sorters[sort_by]
    hotels.sort(key=key)
    best = hotels[0]
    return {
        "found": True, "city": city, "sort_by": sort_by, "options": hotels[:limit], "recommended": best,
        "reason": (f"{best['name']} has the {label} among {len(hotels)} matching hotel(s): "
                   f"{best['stars']}-star at {CURRENCY}{best['price_per_night']}/night."),
    }


# --------------------------------------------------------------------------- places


def discover_places(city: str, types: list[str] | None = None, min_rating: float = 0.0,
                    limit: int = 6) -> dict[str, Any]:
    """Recommend attractions in ``city`` by type and rating (highest rated first)."""
    city = normalize_city(city)
    wanted = {t.strip().lower() for t in (types or []) if t.strip()}
    in_city = [p for p in load_places() if p["city"] == city]
    if not in_city:
        return {"found": False, "city": city, "error": f"No places found for '{city}'."}

    matches = [p for p in in_city if p["rating"] >= min_rating and (not wanted or p["type"] in wanted)]
    matches.sort(key=lambda p: (-p["rating"], p["name"]))
    results = [{**p, "label": f"{p['name']} ({p['type']})"} for p in matches[:limit]]
    return {
        "found": bool(results), "city": city,
        "available_types": sorted({p["type"] for p in in_city}),
        "places": results,
        **({} if results else {"error": "No places match the type/rating filters."}),
    }


# --------------------------------------------------------------------------- budget


def estimate_budget(flight_price_per_person: float, hotel_price_per_night: float, nights: int,
                    travelers: int = 1,
                    daily_local_expense: float = DEFAULT_DAILY_LOCAL_EXPENSE) -> dict[str, Any]:
    """Total cost = flights + hotel rooms + local expenses.

    ``flight_price_per_person`` should already include any return flight.
    One room is assumed per two travelers. Local expenses (food and local transport)
    are charged per person for ``nights + 1`` days.
    """
    travelers = max(1, int(travelers))
    nights = max(0, int(nights))
    rooms = math.ceil(travelers / 2)
    flights_total = round(flight_price_per_person * travelers)
    hotel_total = round(hotel_price_per_night * nights * rooms)
    local_total = round(daily_local_expense * (nights + 1) * travelers)
    return {
        "currency": CURRENCY, "travelers": travelers, "rooms": rooms, "nights": nights,
        "flights": flights_total, "hotel": hotel_total, "food_and_local_travel": local_total,
        "total": flights_total + hotel_total + local_total,
        "assumptions": f"{rooms} room(s); {CURRENCY}{int(daily_local_expense)} per person per day "
                       "for food and local travel.",
    }
