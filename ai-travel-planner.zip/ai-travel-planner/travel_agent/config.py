"""Static configuration: paths, city coordinates, aliases and defaults."""

from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"

# Latitude / longitude used for the Open-Meteo weather lookup.
CITY_COORDINATES = {
    "Delhi": (28.6139, 77.2090),
    "Mumbai": (19.0760, 72.8777),
    "Goa": (15.2993, 74.1240),
    "Bangalore": (12.9716, 77.5946),
    "Chennai": (13.0827, 80.2707),
    "Hyderabad": (17.3850, 78.4867),
    "Kolkata": (22.5726, 88.3639),
    "Jaipur": (26.9124, 75.7873),
}

# Alternative spellings users commonly type.
CITY_ALIASES = {
    "new delhi": "Delhi",
    "bengaluru": "Bangalore",
    "bombay": "Mumbai",
    "calcutta": "Kolkata",
    "madras": "Chennai",
    "panaji": "Goa",
}

DEFAULT_DAILY_LOCAL_EXPENSE = 1500  # INR per person per day (food + local travel)
MAX_TRIP_DAYS = 7
MIN_TRIP_DAYS = 3
CURRENCY = "₹"
