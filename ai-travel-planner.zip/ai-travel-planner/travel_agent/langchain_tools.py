"""LangChain tool wrappers around the core travel functions."""

import json
from typing import Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from . import tools, weather
from .config import DEFAULT_DAILY_LOCAL_EXPENSE


def _as_json(result: dict) -> str:
    return json.dumps(result, ensure_ascii=False, default=str)


class FlightInput(BaseModel):
    origin: str = Field(description="Departure city, e.g. 'Delhi'")
    destination: str = Field(description="Arrival city, e.g. 'Goa'")
    sort_by: str = Field(default="cheapest", description="'cheapest' or 'fastest'")
    max_price: Optional[int] = Field(default=None, description="Optional maximum ticket price in INR")


class HotelInput(BaseModel):
    city: str = Field(description="City to stay in")
    min_stars: int = Field(default=0, description="Minimum star rating (1-5)")
    max_price: Optional[int] = Field(default=None, description="Maximum price per night in INR")
    amenities: Optional[list[str]] = Field(
        default=None, description="Required amenities, e.g. ['wifi','pool','breakfast','gym','spa','parking']")
    sort_by: str = Field(default="value", description="'value', 'rating' or 'price'")


class PlacesInput(BaseModel):
    city: str = Field(description="City to find attractions in")
    types: Optional[list[str]] = Field(
        default=None, description="Place types such as beach, fort, temple, museum, park, lake, market, monument")
    min_rating: float = Field(default=0.0, description="Minimum rating (0-5)")
    limit: int = Field(default=6, description="Maximum number of places to return")


class WeatherInput(BaseModel):
    city: str = Field(description="City to get weather for")
    start_date: str = Field(description="First day of the trip, YYYY-MM-DD")
    days: int = Field(description="Number of days of weather needed (1-16)")


class BudgetInput(BaseModel):
    flight_price_per_person: float = Field(description="Total flight cost per person (include return flight)")
    hotel_price_per_night: float = Field(description="Hotel price per night for one room")
    nights: int = Field(description="Number of nights (trip days minus 1)")
    travelers: int = Field(default=1, description="Number of travelers")
    daily_local_expense: float = Field(
        default=DEFAULT_DAILY_LOCAL_EXPENSE, description="Food + local travel per person per day in INR")


def build_tools() -> list[StructuredTool]:
    """Return the five tools the agent can call."""
    return [
        StructuredTool.from_function(
            func=lambda **kw: _as_json(tools.search_flights(**kw)),
            name="flight_search",
            description="Search flights between two cities in the flights dataset. Returns the cheapest or "
                        "fastest option with a reason. Falls back to one-stop routes if no direct flight exists.",
            args_schema=FlightInput),
        StructuredTool.from_function(
            func=lambda **kw: _as_json(tools.recommend_hotels(**kw)),
            name="hotel_recommendation",
            description="Recommend hotels in a city filtered by stars, price and amenities, ranked by value, "
                        "rating or price.",
            args_schema=HotelInput),
        StructuredTool.from_function(
            func=lambda **kw: _as_json(tools.discover_places(**kw)),
            name="places_discovery",
            description="Find top-rated attractions in a city, optionally filtered by place type.",
            args_schema=PlacesInput),
        StructuredTool.from_function(
            func=lambda **kw: _as_json(weather.get_weather(**kw)),
            name="weather_lookup",
            description="Get the day-by-day weather forecast (Open-Meteo) for a city and travel dates.",
            args_schema=WeatherInput),
        StructuredTool.from_function(
            func=lambda **kw: _as_json(tools.estimate_budget(**kw)),
            name="budget_estimation",
            description="Estimate the total trip cost from flight, hotel and daily local expenses.",
            args_schema=BudgetInput),
    ]
